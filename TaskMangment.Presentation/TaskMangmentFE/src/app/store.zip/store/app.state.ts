import { AuthState } from './auth/auth.state';
import { NavState } from './nav/nav.reducer';
import { UserState } from './user/user.reducer';
import { BranchState } from "./branch/branch.state";


export interface AppState {
  auth: AuthState;
  nav: NavState;
  user: UserState;
  branch: BranchState;
}
