import { createAction, props } from "@ngrx/store";
import { BranchModel } from "app/core/models/branch/branch-model";
import { SearchCriteria } from "app/core/models/search-criteria.model";

//load Branchs
export const loadBranchs = createAction(
  '[Branch] Load Branchs',
  props<{ searchCriteria: SearchCriteria; entries: number }>()
);

export const loadBranchsSuccess = createAction(
    '[Branch] Load Branchs Success',
    props<{ data: BranchModel[]; totalItems: number; targetPage: number; itemCount: number }>()
);

export const loadBranchsFailure = createAction(
    '[Branch] Load Branchs Failure',
    props<{ error: any }>()
);