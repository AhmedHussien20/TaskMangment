import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { Actions, createEffect, ofType } from "@ngrx/effects";
import { ToastrService } from "ngx-toastr";
import * as BranchActions from './branch.actions';
import { catchError, map, mergeMap, tap } from 'rxjs/operators';
import { of } from 'rxjs';
import { BranchService } from "app/core/services/branch.service";

@Injectable()
export class BranchEffects {
  loadBranchs$:any;
  constructor(
        private actions$: Actions,
        private branchService: BranchService,
        private router: Router, // Inject Router
        private toastr: ToastrService // Inject Toastr
  )
  {
    console.log('🔄 loadBrachs action triggered');
    this.loadBranchs();
  }
 //load
  private loadBranchs(){
    this.loadBranchs$ = createEffect(() =>
      this.actions$.pipe(
        ofType(BranchActions.loadBranchs),
        tap(() => console.log('🔄 loadBrachs action triggered')),
        mergeMap(action =>
          this.branchService.fetchBranchs(action.searchCriteria, action.entries).pipe(
            tap(response => console.log('✅ API Response:', response)),
            map(response => BranchActions.loadBranchsSuccess({ 
              data: response.data, 
              totalItems: response.totalItems, 
              targetPage: response.targetPage, 
              itemCount: response.itemCount 
            })),
            catchError(error => {
              console.error('❌ API Error:', error);
              this.toastr.error('Failed to load groups.','Error');
              return of(BranchActions.loadBranchsFailure({ error }));
            })
          )
        )
      )
    );
  }
}