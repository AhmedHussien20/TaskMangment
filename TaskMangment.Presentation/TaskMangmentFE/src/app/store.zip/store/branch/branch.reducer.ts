import { createReducer, on } from "@ngrx/store";
import * as BranchActions from './branch.actions';
import { BranchState } from "./branch.state";
import { state } from "@angular/animations";

export const initialState: BranchState = {
  data: [],
  totalItems: 0,
  targetPage: 0,
  itemCount: 0,
  error: null
};

export const branchReducer=createReducer(
    initialState,
    on(BranchActions.loadBranchsSuccess,(state, { data, totalItems, targetPage, itemCount })=>({
        ...state,
    data,
    totalItems,
    targetPage,
    itemCount,
    error: null
    })),
    on(BranchActions.loadBranchsFailure,(state,{error})=>({
        ...state,
        error
    }))

)
