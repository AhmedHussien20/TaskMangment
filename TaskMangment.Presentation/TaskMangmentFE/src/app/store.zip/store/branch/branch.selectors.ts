import { createFeatureSelector, createSelector } from "@ngrx/store";
import { BranchState } from "./branch.state";
import { state } from "@angular/animations";

export const selectBranchState=createFeatureSelector<BranchState>('branch');

export const selectAllBranchs=createSelector(
    selectBranchState,
    (state:BranchState)=>state.data
);

export const selectBranchTotal=createSelector(
    selectBranchState,
    (state:BranchState)=>state.totalItems
);

export const selectBranchTargetPage=createSelector(
    selectBranchState,
    (state:BranchState)=>state.targetPage
)
