import { BranchModel } from "app/core/models/branch/branch-model";

export interface BranchState {
    data: BranchModel[];
    totalItems: number;
    targetPage: number;
    itemCount: number;
    error: any;
  }

  export const initialState: BranchState = {
    data: [],
    totalItems: 0,
    targetPage: 0,
    itemCount: 0,
    error: null,
  };