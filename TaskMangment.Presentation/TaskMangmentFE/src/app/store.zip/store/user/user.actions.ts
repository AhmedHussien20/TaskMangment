import { createAction, props } from '@ngrx/store';
import { CreateUserDto } from 'app/core/models/create-user.dto';
import { UserFilterDto } from 'app/core/models/user-filter.dto';

// Action triggered when users are successfully loaded
export const loadUsersSuccess = createAction(
  '[User] Load Users Success',
  props<{ data: UserFilterDto[], totalItems: number; targetPage: number; totalPages: number; itemCount: number }>()
);

// Action triggered when loading users fails
export const loadUsersFailure = createAction(
  '[User] Load Users Failure',
  props<{ error: string }>()
);

// Action to list users
export const loadUsers = createAction(
  '[User] Load Users',
  props<{ filter: UserFilterDto; entries: number }>()
);
