import { Injectable } from '@angular/core';
import { Actions, ofType, createEffect } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { UserService } from 'app/core/services/user.service';
import * as UserActions from './user.actions';

@Injectable()
export class UserEffects {
    loadUsers$ : any;
    constructor(private actions$: Actions, private userService: UserService) {
        this.loadUser();
    }
    private loadUser(){
        this.loadUsers$ = createEffect(() =>
            this.actions$.pipe(
              ofType(UserActions.loadUsers),
              mergeMap((action) =>
                this.userService.getAllUsers(action.filter).pipe(
                  map((response) =>
                    UserActions.loadUsersSuccess({
                      data: response.data,
                      totalItems: response.totalItems,
                      targetPage: response.targetPage,
                      totalPages: response.totalPages,
                      itemCount: response.itemCount,
                    })
                  ),
                  catchError((error) =>
                    of(UserActions.loadUsersFailure({ error: error.message }))
                  )
                )
              )
            )
          );
    }
   
 
}
