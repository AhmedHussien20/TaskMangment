import { createReducer, on } from '@ngrx/store';
import * as UserActions from './user.actions';  
import { UserState } from './user.state';

export const initialUserState: UserState = {
  data: [],
  totalItems: 0,
  totalPages: 0,
  targetPage: 0,
  pageCount: 10,
  loading: false,
  error: null,
}
 

export const userReducer = createReducer(
  initialUserState,
  on(UserActions.loadUsersSuccess, (state, { data, totalItems, targetPage, totalPages }) => ({
    ...state,
    data: data,
    totalItems: totalItems,
    targetPage,
    totalPages,
    error: null,
  })),
  on(UserActions.loadUsersFailure, (state, { error }) => ({
    ...state,
    error,
  }))
);

export type { UserState };

