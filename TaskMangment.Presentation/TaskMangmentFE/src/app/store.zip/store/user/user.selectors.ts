import { createFeatureSelector, createSelector, select } from '@ngrx/store'; 
import { UserState } from './user.state';

export const selectUserState = createFeatureSelector<UserState>('user');

export const selectAllUsers = createSelector(
  selectUserState,
  (state) => state.data
);

export const selectUserLoading = createSelector(
  selectUserState,
  (state) => state.loading
);

export const selectUserError = createSelector(
  selectUserState,
  (state) => state.error
);

export const selectUserPagination = createSelector(
  selectUserState,
  (state) => ({
    totalItems: state.totalItems,
    targetPage: state.targetPage,
    totalPages: state.totalPages,
    itemCount: state.data.length, // Assuming data is an array of users
  })
);

export const selectUserTargetPage = createSelector(
  selectUserState,
  (state: UserState) => state.targetPage
);

export const selectUserTotalPages = createSelector(
  selectUserState,
  (state: UserState) => state?.totalPages || 0 // Safely access `totalPages` and default to 0
);

export const selectTotalItems = createSelector(
  selectUserState,
  (state: UserState) => state.totalItems
);