import { UserFilterDto } from 'app/core/models/user-filter.dto';

export interface UserState {
  data: UserFilterDto[];
  totalItems: number;
  totalPages: number;
  targetPage: number;
  pageCount: number; // Add pageCount property
  loading: boolean;
  error: string | null;
  users?: any[]; // Add this property
  itemCount?: number; // Add this property
}

export const initialCustomerState: UserState = {
  data: [],
  totalItems: 0,
  totalPages: 0,
  targetPage: 0,
  pageCount: 10, // Initialize pageCount with a default value
  loading: false,
  error: null,
};